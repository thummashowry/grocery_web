(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/lib/data/mock.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "deliverySlots": (()=>deliverySlots),
    "featuredCategories": (()=>featuredCategories),
    "products": (()=>products),
    "promoCards": (()=>promoCards),
    "staffOrders": (()=>staffOrders),
    "trackingEvents": (()=>trackingEvents)
});
const featuredCategories = [
    {
        name: "Fruits",
        image: "https://images.unsplash.com/photo-1577234286642-fc512a5f8f11"
    },
    {
        name: "Vegetables",
        image: "https://images.unsplash.com/photo-1540420773420-3366772f4999"
    },
    {
        name: "Dairy",
        image: "https://images.unsplash.com/photo-1550583724-b2692b85b150"
    },
    {
        name: "Bakery",
        image: "https://images.unsplash.com/photo-1608198093002-ad4e005484ec"
    },
    {
        name: "Organic",
        image: "https://images.unsplash.com/photo-1542838132-92c53300491e"
    }
];
const products = [
    {
        id: "p1",
        slug: "organic-avocado-hass",
        name: "Organic Hass Avocado",
        category: "Fruits",
        description: "Creamy, ripe, and ideal for toast, salads, and guacamole.",
        image: "https://images.unsplash.com/photo-1519162808019-7de1683fa2ad",
        gallery: [
            "https://images.unsplash.com/photo-1519162808019-7de1683fa2ad",
            "https://images.unsplash.com/photo-1594282486552-05a594abfc7f",
            "https://images.unsplash.com/photo-1603048719539-9ace5a0e7f58"
        ],
        price: 4.2,
        unit: "kg",
        weightLabel: "~250g each",
        inStock: true,
        stockLevel: 48,
        bufferedStock: 8,
        tags: [
            "Organic",
            "Vegan",
            "Gluten-Free",
            "Dairy-Free"
        ],
        nutrition: {
            calories: "160 kcal",
            protein: "2g",
            carbs: "9g",
            fat: "15g"
        }
    },
    {
        id: "p2",
        slug: "wild-blueberries",
        name: "Wild Blueberries",
        category: "Fruits",
        description: "Naturally sweet berries packed with antioxidants.",
        image: "https://images.unsplash.com/photo-1498557850523-fd3d118b962e",
        gallery: [
            "https://images.unsplash.com/photo-1498557850523-fd3d118b962e",
            "https://images.unsplash.com/photo-1464965911861-746a04b4bca6",
            "https://images.unsplash.com/photo-1596591868231-05e0f53a74ff"
        ],
        price: 7.8,
        unit: "kg",
        weightLabel: "125g punnet",
        inStock: true,
        stockLevel: 35,
        bufferedStock: 6,
        tags: [
            "Organic",
            "Vegan",
            "Gluten-Free",
            "Dairy-Free"
        ],
        nutrition: {
            calories: "57 kcal",
            protein: "0.7g",
            carbs: "14g",
            fat: "0.3g"
        }
    },
    {
        id: "p3",
        slug: "farm-spinach",
        name: "Farm Baby Spinach",
        category: "Vegetables",
        description: "Freshly picked, crisp leaves for green bowls and smoothies.",
        image: "https://images.unsplash.com/photo-1576045057995-568f588f82fb",
        gallery: [
            "https://images.unsplash.com/photo-1576045057995-568f588f82fb",
            "https://images.unsplash.com/photo-1576678927484-cc907957088c",
            "https://images.unsplash.com/photo-1615486363972-f79e9a8c7f8c"
        ],
        price: 5.9,
        unit: "kg",
        weightLabel: "200g bag",
        inStock: true,
        stockLevel: 21,
        bufferedStock: 5,
        tags: [
            "Organic",
            "Vegan",
            "Gluten-Free",
            "Dairy-Free"
        ],
        nutrition: {
            calories: "23 kcal",
            protein: "2.9g",
            carbs: "3.6g",
            fat: "0.4g"
        }
    },
    {
        id: "p4",
        slug: "almond-milk-unsweetened",
        name: "Unsweetened Almond Milk",
        category: "Dairy",
        description: "Barista blend almond milk with silky foam texture.",
        image: "https://images.unsplash.com/photo-1600788907416-456578634209",
        gallery: [
            "https://images.unsplash.com/photo-1600788907416-456578634209",
            "https://images.unsplash.com/photo-1559561853-08451507cbe7",
            "https://images.unsplash.com/photo-1623065422902-30a2d299bbe4"
        ],
        price: 3.4,
        unit: "bottle",
        weightLabel: "1L bottle",
        inStock: true,
        stockLevel: 62,
        bufferedStock: 10,
        tags: [
            "Vegan",
            "Gluten-Free",
            "Dairy-Free"
        ],
        nutrition: {
            calories: "14 kcal",
            protein: "0.4g",
            carbs: "0.2g",
            fat: "1.2g"
        }
    },
    {
        id: "p5",
        slug: "sourdough-loaf",
        name: "Stoneground Sourdough Loaf",
        category: "Bakery",
        description: "Slow-fermented artisan loaf with crisp crust and airy center.",
        image: "https://images.unsplash.com/photo-1549931319-a545dcf3bc73",
        gallery: [
            "https://images.unsplash.com/photo-1549931319-a545dcf3bc73",
            "https://images.unsplash.com/photo-1509440159596-0249088772ff",
            "https://images.unsplash.com/photo-1577985051167-0d49eec21977"
        ],
        price: 6.8,
        unit: "pcs",
        weightLabel: "650g loaf",
        inStock: false,
        stockLevel: 0,
        bufferedStock: 2,
        tags: [
            "Organic"
        ],
        nutrition: {
            calories: "232 kcal",
            protein: "8g",
            carbs: "44g",
            fat: "2g"
        }
    },
    {
        id: "p6",
        slug: "greek-yogurt",
        name: "Greek Yogurt 2%",
        category: "Dairy",
        description: "Thick, creamy cultured yogurt made from local milk.",
        image: "https://images.unsplash.com/photo-1488477181946-6428a0291777",
        gallery: [
            "https://images.unsplash.com/photo-1488477181946-6428a0291777",
            "https://images.unsplash.com/photo-1514996937319-344454492b37",
            "https://images.unsplash.com/photo-1505253213348-cd54c92b37e3"
        ],
        price: 4.9,
        unit: "pcs",
        weightLabel: "500g tub",
        inStock: true,
        stockLevel: 17,
        bufferedStock: 3,
        tags: [
            "Gluten-Free"
        ],
        nutrition: {
            calories: "59 kcal",
            protein: "10g",
            carbs: "3.6g",
            fat: "0.4g"
        }
    }
];
const promoCards = [
    {
        title: "Green Basket Weekend",
        subtitle: "Save 18% on all organic produce",
        cta: "Claim Offer"
    },
    {
        title: "Bakery Morning Drop",
        subtitle: "Fresh sourdough and pastries before 9:00",
        cta: "Schedule Delivery"
    }
];
const deliverySlots = [
    {
        id: "s1",
        label: "Today 6:00 - 8:00 PM",
        capacity: "3 spots left",
        available: true
    },
    {
        id: "s2",
        label: "Tomorrow 8:00 - 10:00 AM",
        capacity: "12 spots left",
        available: true
    },
    {
        id: "s3",
        label: "Tomorrow 7:00 - 9:00 PM",
        capacity: "Full",
        available: false
    }
];
const staffOrders = [
    {
        id: "ORD-2845",
        customerName: "Lina Berg",
        items: 14,
        total: 92.3,
        status: "Pending",
        eta: "22 min",
        requiresWeightAdjustment: true
    },
    {
        id: "ORD-2844",
        customerName: "Noah Lang",
        items: 7,
        total: 41.5,
        status: "Picking",
        eta: "14 min",
        requiresWeightAdjustment: false
    },
    {
        id: "ORD-2843",
        customerName: "Mia Chen",
        items: 11,
        total: 67.9,
        status: "Completed",
        eta: "Courier assigned",
        requiresWeightAdjustment: false
    }
];
const trackingEvents = [
    {
        id: "t1",
        status: "Pending",
        time: "10:24 AM",
        note: "Order confirmed and queued for store picking"
    },
    {
        id: "t2",
        status: "Picking",
        time: "10:40 AM",
        note: "Picker is selecting fresh produce and weight-based items"
    },
    {
        id: "t3",
        status: "Completed",
        time: "11:02 AM",
        note: "All items packed with cold-chain handling"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/checkout-steps.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "CheckoutSteps": (()=>CheckoutSteps)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$data$2f$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/data/mock.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const steps = [
    "Address",
    "Delivery",
    "Payment",
    "Review"
];
function CheckoutSteps() {
    _s();
    const [step, setStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "space-y-5 rounded-2xl border border-spruce-100 bg-white p-4 shadow-soft sm:p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-4 gap-2 text-center text-xs font-semibold",
                children: steps.map((label, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setStep(index),
                        className: `rounded-xl px-2 py-2 ${step === index ? "bg-spruce-600 text-white" : "bg-spruce-50 text-spruce-700"}`,
                        children: label
                    }, label, false, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 16,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/checkout-steps.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            step === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-3 sm:grid-cols-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        className: "rounded-xl border border-spruce-100 p-3 text-sm",
                        placeholder: "Full name"
                    }, void 0, false, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 28,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        className: "rounded-xl border border-spruce-100 p-3 text-sm",
                        placeholder: "Phone"
                    }, void 0, false, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 29,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        className: "rounded-xl border border-spruce-100 p-3 text-sm sm:col-span-2",
                        placeholder: "Street address"
                    }, void 0, false, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 30,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        className: "rounded-xl border border-spruce-100 p-3 text-sm",
                        placeholder: "City"
                    }, void 0, false, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 31,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        className: "rounded-xl border border-spruce-100 p-3 text-sm",
                        placeholder: "Postal code"
                    }, void 0, false, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 32,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/checkout-steps.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, this) : null,
            step === 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-2",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$data$2f$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deliverySlots"].map((slot)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "flex items-center justify-between rounded-xl border border-spruce-100 p-3 text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: slot.label
                            }, void 0, false, {
                                fileName: "[project]/components/checkout-steps.tsx",
                                lineNumber: 40,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-slate-500",
                                        children: slot.capacity
                                    }, void 0, false, {
                                        fileName: "[project]/components/checkout-steps.tsx",
                                        lineNumber: 42,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "radio",
                                        name: "slot",
                                        disabled: !slot.available
                                    }, void 0, false, {
                                        fileName: "[project]/components/checkout-steps.tsx",
                                        lineNumber: 43,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/checkout-steps.tsx",
                                lineNumber: 41,
                                columnNumber: 15
                            }, this)
                        ]
                    }, slot.id, true, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 39,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/checkout-steps.tsx",
                lineNumber: 37,
                columnNumber: 9
            }, this) : null,
            step === 2 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-2 text-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "rounded-xl border border-spruce-100 p-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "radio",
                                name: "payment",
                                className: "mr-2",
                                defaultChecked: true
                            }, void 0, false, {
                                fileName: "[project]/components/checkout-steps.tsx",
                                lineNumber: 53,
                                columnNumber: 13
                            }, this),
                            "Card ending in 4821"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 52,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "rounded-xl border border-spruce-100 p-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "radio",
                                name: "payment",
                                className: "mr-2"
                            }, void 0, false, {
                                fileName: "[project]/components/checkout-steps.tsx",
                                lineNumber: 57,
                                columnNumber: 13
                            }, this),
                            "Apple Pay"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 56,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "rounded-xl border border-spruce-100 p-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "radio",
                                name: "payment",
                                className: "mr-2"
                            }, void 0, false, {
                                fileName: "[project]/components/checkout-steps.tsx",
                                lineNumber: 61,
                                columnNumber: 13
                            }, this),
                            "Cash on delivery"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/checkout-steps.tsx",
                        lineNumber: 60,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/checkout-steps.tsx",
                lineNumber: 51,
                columnNumber: 9
            }, this) : null,
            step === 3 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-xl bg-spruce-50 p-4 text-sm text-slate-700",
                children: "Your order is ready for confirmation. Delivery fee and weight adjustment will be finalized at packing."
            }, void 0, false, {
                fileName: "[project]/components/checkout-steps.tsx",
                lineNumber: 68,
                columnNumber: 9
            }, this) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>setStep((prev)=>Math.min(prev + 1, steps.length - 1)),
                    className: "inline-flex items-center gap-1 rounded-xl bg-ink px-4 py-2.5 text-sm font-semibold text-white",
                    children: [
                        "Continue",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                            className: "h-4 w-4"
                        }, void 0, false, {
                            fileName: "[project]/components/checkout-steps.tsx",
                            lineNumber: 79,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/checkout-steps.tsx",
                    lineNumber: 74,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/checkout-steps.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/checkout-steps.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_s(CheckoutSteps, "5L63dQvunH1XgKOLcNNkxeDh1IM=");
_c = CheckoutSteps;
var _c;
__turbopack_context__.k.register(_c, "CheckoutSteps");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * @license lucide-react v0.516.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s({
    "__iconNode": (()=>__iconNode),
    "default": (()=>ChevronRight)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m9 18 6-6-6-6",
            key: "mthhwq"
        }
    ]
];
const ChevronRight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("chevron-right", __iconNode);
;
 //# sourceMappingURL=chevron-right.js.map
}}),
"[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ChevronRight": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript)");
}}),
}]);

//# sourceMappingURL=_6905d5fc._.js.map