(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_globals_73c37791.css",
  "static/chunks/node_modules_57c31df5._.js",
  "static/chunks/_80104ec6._.js"
],
    source: "dynamic"
});
